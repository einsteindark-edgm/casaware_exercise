"""Restore the bronze-CDC return route when something deletes it.

Triggered by EventBridge rule `nexus-dev-edgm-route-drift`, which fires
on DeleteRoute / ReplaceRoute targeting rtb-... (the MSK private rtb).

Idempotent: if the route is already present we no-op. Logs every action
so you can see WHO did the delete by correlating with the trigger event.
"""
import json
import logging
import os
import boto3
from botocore.exceptions import ClientError

log = logging.getLogger()
log.setLevel(logging.INFO)
ec2 = boto3.client("ec2")

RTB    = os.environ["ROUTE_TABLE_ID"]
CIDR   = os.environ["DESTINATION_CIDR_BLOCK"]
PCX    = os.environ["VPC_PEERING_CONNECTION_ID"]


def handler(event, context):
    log.info("trigger event: %s", json.dumps(event))
    detail = event.get("detail", {}) or {}
    rp = detail.get("requestParameters", {}) or {}

    # Only act when the offending event matches OUR route.
    if rp.get("routeTableId") != RTB:
        log.info("ignoring: rtb mismatch (%s != %s)", rp.get("routeTableId"), RTB)
        return {"status": "ignored_rtb"}
    if rp.get("destinationCidrBlock") not in (CIDR, None):
        # None = ReplaceRoute on a different cidr — only heal our cidr.
        log.info("ignoring: cidr mismatch (%s != %s)", rp.get("destinationCidrBlock"), CIDR)
        return {"status": "ignored_cidr"}

    # If a route for our CIDR already exists, no-op.
    rtb = ec2.describe_route_tables(RouteTableIds=[RTB])["RouteTables"][0]
    for r in rtb.get("Routes", []):
        if r.get("DestinationCidrBlock") == CIDR and r.get("VpcPeeringConnectionId") == PCX and r.get("State") == "active":
            log.info("no-op: route already present and active")
            return {"status": "noop_present"}

    actor = detail.get("userIdentity", {}).get("arn", "?")
    src   = detail.get("sourceIPAddress", "?")
    ua    = detail.get("userAgent", "?")
    log.warning(
        "RESTORING route %s -> %s on %s. Deleted by actor=%s ip=%s ua=%s",
        CIDR, PCX, RTB, actor, src, ua,
    )

    try:
        ec2.create_route(
            RouteTableId=RTB,
            DestinationCidrBlock=CIDR,
            VpcPeeringConnectionId=PCX,
        )
        return {"status": "restored", "actor": actor}
    except ClientError as e:
        # If the route exists (race with another invocation), that's fine.
        if e.response.get("Error", {}).get("Code") == "RouteAlreadyExists":
            return {"status": "raced_already_exists"}
        raise
